信臣健康互联网医院 - 部署包
===============================

部署步骤：

1. 解压此文件到服务器目录：
   tar -xzf medseek-deploy-*.tar.gz
   cd medseek-deploy-*

2. 编辑.env文件，配置DeepSeek API密钥：
   nano .env
   
   必填项：
   DEEPSEEK_API_KEY=你的API密钥
   PORT=8080

3. 设置执行权限：
   chmod +x medseek

4. 测试运行：
   ./medseek
   
   访问 http://服务器IP:8080 测试

5. 配置systemd服务（推荐生产环境）：
   参考完整部署文档：DEPLOYMENT.md

文件说明：
- medseek: 后端可执行文件
- dist/: 前端静态文件
- .env: 环境配置文件（需要编辑）

更多详细信息请参考项目中的 DEPLOYMENT.md 文档。
